﻿using System;

namespace Utilities.Courses
{
   class Program
   {
      static void Main(string[] args)
      {
         Random random = new Random(0);
         string s = null; // QHelper.GetApplesAndOranges(random, null);         
      }
   }
}
