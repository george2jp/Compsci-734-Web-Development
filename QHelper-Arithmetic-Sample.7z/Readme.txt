One-off preparation:
1) To run PowerShell scripts, you need to do this one-off setup: (1) Run PowerShell as admin. (2) Issue the command: "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned"
2) To convert HTML to PDF, you need to do this one-off software installation: install the converter called wkhtmltopdf
3) Often, it would be useful to merge all PDFs into a single one. For this, do this one-off software installation: install pdftk

Compile the solution.
Issue the following commands in PowerShell:

cd bin/Debug (or bin/Release, if appropriate).
TestGen -paperCount 20 -library QHelper.dll Arithmetic.Task.html
_ConvertAll2Pdf.ps1 (if required)
_PdfMergeThemAll.ps1 (if required)

To generate the sheets with answers, use the -proof option with TestGen. This enables the code within class cws_code_a to be visible.
TestGen -paperCount 20 -library QHelper.dll -proof Arithmetic.Task.html
