﻿// Dummy class to help with quick debugging. S Manoharan.

namespace Utilities.Courses
{
   class Program
   {
      public static void Main(string[] args)
      {
         ColorSpace assignment = new ColorSpace();
         uint uid = 1234567;
         string sum = assignment.GetSum(uid);
      }
   }
}
